angular
.module('app', ['firebase'])
.constant('firebaseConfig', {
apiKey: "AIzaSyACR-A2Kbsr8IrEbSNht-GoB2i_Mfdn18U",
    authDomain: "final-1f980.firebaseapp.com",
    databaseURL: "https://final-1f980.firebaseio.com",
    projectId: "final-1f980",
    storageBucket: "final-1f980.appspot.com",
    messagingSenderId: "691487186782",
})
  .run(firebaseConfig => firebase.initializeApp(firebaseConfig))
  .service('dbRefRoot', DbRefRoot)
  .service('tasks', tasks)
  .controller('contactCtrl', contactCtrl)

function DbRefRoot() {
    return firebase.database().ref()
}

function tasks(dbRefRoot, $firebaseObject, $firebaseArray) {
    const dbReftasks = dbRefRoot.child('tasks')

    this.get = function get(id) {
        return $firebaseObject(dbReftasks.child(id))
    }

    this.getAll = function getAll() {
        return $firebaseArray(dbReftasks)
    }

}

function contactCtrl(tasks) {

    this.getnewTask = function getnewTask() {
        return {
            description: '',
            dueDate: '',
            category: '',
            comment: '',
            priority:'',
            doneTask:false
        }
    }

    this.filterCat = "";
  
    this.newTask = this.getnewTask()

    this.tasks = tasks.getAll()

    this.remove = function remove(task) {
        this.tasks.$remove(task)
    }

    this.save = function save(task) {
        this.tasks.$save(task)
    }

    this.addTask = function addTaskItem(newTask) {
        this.tasks.$add(newTask)
        .then( newRef => {
            console.log('new task id = ' + newRef.key)
            this.newTask = this.getnewTask()
        })
    
    }
};


